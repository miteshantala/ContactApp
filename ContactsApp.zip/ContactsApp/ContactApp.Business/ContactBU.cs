﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ContactApp.Entity;


namespace ContactApp.Business
{
    public class ContactBU
    {
        ContactDBEntities db = new ContactDBEntities();

        ~ContactBU()
        {
            db.Dispose();
        }

        public IEnumerable<Contact> GetList()
        {
            try
            {
                return db.Contacts.ToList();
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                throw;
            }
        }

        public Contact Get(int contactID)
        {
            try
            {
                return db.Contacts.Single(i => i.ContactID == contactID);
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                throw;
            }
        }

        public Contact Save(Contact contact)
        {
            try
            {
                if (contact.ContactID > 0)
                {
                    contact.ModifiedBy = 1;// current user
                    contact.ModifiedOn = DateTime.Now;
                    return Update(contact);
                }

                else
                {
                    contact.CreatedBy = 1;// current user
                    contact.CreatedOn = DateTime.Now;
                    return Add(contact);
                }

            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                throw;
            }
        }

        private Contact Add(Contact contact)
        {
            try
            {
                db.Contacts.Add(contact);
                db.SaveChanges();
                return contact;
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                throw;
            }
        }

        private Contact Update(Contact contact)
        {
            try
            {
                var dbContact = Get(contact.ContactID);
                dbContact.FirstName = contact.FirstName;
                dbContact.LastName = contact.LastName;
                dbContact.Email = contact.Email;
                dbContact.Phone = contact.Phone;
                dbContact.IsActive = contact.IsActive;
                dbContact.CreatedBy = contact.CreatedBy;
                dbContact.CreatedOn = contact.CreatedOn;
                dbContact.ModifiedBy = contact.ModifiedBy;
                dbContact.ModifiedOn = contact.ModifiedOn;
                db.Entry(dbContact).State = System.Data.Entity.EntityState.Modified;
                db.SaveChanges();
                return dbContact;
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                throw;
            }
        }

        public bool Delete(int contactID)
        {
            try
            {
                var dbContact = Get(contactID);
                dbContact.IsActive = false;  // make isActive false, it is equal to delete
                db.SaveChanges();
                return true;
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                throw;
            }
        }
    }
}
