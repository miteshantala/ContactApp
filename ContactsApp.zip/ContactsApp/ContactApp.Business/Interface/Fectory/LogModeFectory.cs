﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ContactApp.Business
{
    public class LogModeFectory
    {
        private Dictionary<string, ILogMode> _logModes = new Dictionary<string, ILogMode>();

        public LogModeFectory()
        {
            if (!_logModes.Any())
            {
                _logModes.Add("FILE", new LogModeFile());
                _logModes.Add("DB", new LogModeDataBase());
            }
        }
        public ILogMode GetLogMode(string logMode)
        {
            if (_logModes.Keys.Contains(logMode))
            {
                //RIP pattern (replace if with polymorphism)
                return _logModes[logMode];
            }
            else
            {
                throw new NotSupportedException();
            }
        }
    }
}
