﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ContactApp.Business
{
    public interface ILogMode
    {
        void SaveMessage(string message);
        void SaveError(string errorMessage);
        void SaveError(string errorMessage, string errorLocation);
    }
}
