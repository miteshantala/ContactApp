﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ContactApp.Business
{
    public static class Log
    {
        private static ILogMode _logMode;
        private static bool _messageLogEnable = false;
        static Log()
        {
            // Factory design pattern
            _logMode = new LogModeFectory().GetLogMode("DB"); // Get this "DB" value from config
            _messageLogEnable = true; // Get this value from config, if its enable then the message will get logged. Generally its false but for debug in production environment its useful.

        }
        public static void Message(string message)
        {
            _logMode.SaveMessage(message);
        }

        public static void Error(string errorMessage)
        {
            if (_messageLogEnable)
                _logMode.SaveError(errorMessage);

        }
        public static void Error(string errorMessage, string errorLocation)
        {
            _logMode.SaveError(errorMessage, errorLocation);
        }
    }
}