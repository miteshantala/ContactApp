﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ContactApp.Business
{
    /// <summary>
    /// Save error and message in file system
    /// </summary>
    class LogModeFile : ILogMode
    {
        public void SaveError(string errorMessage)
        {
            throw new NotImplementedException();
        }

        public void SaveError(string errorMessage, string errorLocation)
        {
            throw new NotImplementedException();
        }

        public void SaveMessage(string message)
        {
            throw new NotImplementedException();
        }
    }
}
