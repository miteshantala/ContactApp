﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using ContactsApp.Models;
using ContactApp.Entity;

namespace ContactsApp
{
    public class AppHelper
    {
        public static ContactViewModel GetContactViewModel(Contact contact)
        {
            var contactVm = new ContactViewModel();

            contactVm.ContactID = contact.ContactID;
            contactVm.FirstName = contact.FirstName;
            contactVm.LastName = contact.LastName;
            contactVm.Email = contact.Email;
            contactVm.Phone = contact.Phone;
            contactVm.IsActive = contact.IsActive;
            contactVm.CreatedBy = contact.CreatedBy;
            contactVm.CreatedOn = contact.CreatedOn;
            contactVm.ModifiedBy = contact.ModifiedBy;
            contactVm.ModifiedOn = contact.ModifiedOn;

            return contactVm;
        }

        public static Contact GetContact(ContactViewModel contactVm)
        {
            var contact = new Contact();

            contact.ContactID = contactVm.ContactID;
            contact.FirstName = contactVm.FirstName;
            contact.LastName = contactVm.LastName;
            contact.Email = contactVm.Email;
            contact.Phone = contactVm.Phone;
            contact.IsActive = contactVm.IsActive;
            contact.CreatedBy = contactVm.CreatedBy;
            contact.CreatedOn = contactVm.CreatedOn;
            contact.ModifiedBy = contactVm.ModifiedBy;
            contact.ModifiedOn = contactVm.ModifiedOn;

            return contact;
        }
    }
}