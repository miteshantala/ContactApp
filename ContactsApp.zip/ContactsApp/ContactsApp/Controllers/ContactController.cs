﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using ContactApp.Business;
using ContactsApp.Models;
using System.Web.Http.Description;

namespace ContactsApp.Controllers
{
    public class ContactController : ApiController
    {
        // GET api/Contact List
        public IEnumerable<ContactViewModel> Get()
        {
            return new ContactBU().GetList().Select(i => AppHelper.GetContactViewModel(i));
        }

        // GET api/Contact/5
        [ResponseType(typeof(ContactViewModel))]
        public IHttpActionResult Get(int id)
        {
            var contact = new ContactBU().Get(id);
            if (contact == null)
                return NotFound();
            else
                return Ok(AppHelper.GetContactViewModel(contact));
        }

        // POST api/Contact
        [ResponseType(typeof(ContactViewModel))]
        public IHttpActionResult Post(ContactViewModel contactViewModel)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            new ContactBU().Save(AppHelper.GetContact(contactViewModel));

            return Ok(contactViewModel);
        }

        // PUT api/Contact/5
        [ResponseType(typeof(ContactViewModel))]
        public IHttpActionResult Put(ContactViewModel contactViewModel)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            new ContactBU().Save(AppHelper.GetContact(contactViewModel));
            return Ok(contactViewModel);
        }

        // DELETE api/Contact/5
        [ResponseType(typeof(bool))]
        public IHttpActionResult Delete(int id)
        {
            return Ok(new ContactBU().Delete(id));
        }
    }
}
