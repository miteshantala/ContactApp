﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace ContactsApp.Models
{
    public class ContactViewModel
    {
        public string FullName { get { return FirstName + " " + LastName; } }
        public int ContactID { get; set; }

        [Required]
        [MaxLength(50)]
        public string FirstName { get; set; }


        [Required]
        [MaxLength(50)]
        public string LastName { get; set; }


        [DataType(DataType.EmailAddress)]
        [EmailAddress]
        public string Email { get; set; }


        [Required]
        [MaxLength(13)]
        [RegularExpression("^[0-9]*$")]
        public string Phone { get; set; }


        public bool IsActive { get; set; }

        
        public int CreatedBy { get; set; }


        public System.DateTime CreatedOn { get; set; }


        public Nullable<int> ModifiedBy { get; set; }


        public Nullable<System.DateTime> ModifiedOn { get; set; }
    }
}