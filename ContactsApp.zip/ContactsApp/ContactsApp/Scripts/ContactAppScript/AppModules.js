﻿/// <reference path="../AngularJS/angular.js" />

var app;
(function () {
    app = angular.module("contactModule", []);
})();
