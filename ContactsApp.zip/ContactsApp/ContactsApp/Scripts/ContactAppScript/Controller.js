﻿/// <reference path="AppModules.js" />
/// <reference path="../AngularJS/angular.js" />


app.controller('contactController', function ($scope, $filter, contactService) {

    bindGrid();

    function bindGrid() {
        //get from service
        contactService.getContacts().then(function (d) { $scope.contacts = d.data },
              function (error) {
                  $log.error('error while getContacts', error);
              });

    }


    $scope.edit = function (id) {
        var contact = $filter('filter')($scope.contacts, { ContactID: id })[0];
        $scope.contactModel.ContactID = contact.ContactID;
        $scope.contactModel.FirstName = contact.FirstName;
        $scope.contactModel.LastName = contact.LastName ;
        $scope.contactModel.Email = contact.Email ;
        $scope.contactModel.Phone = contact.Phone;
        $scope.contactModel.CreatedBy = contact.CreatedBy;
        $scope.contactModel.CreatedOn = contact.CreatedOn;
    }

    $scope.delete = function (id) {
        contactService.getContacts().then(function (d) {
            $scope.clear();
            bindGrid();
        },
              function (error) {
                  $log.error('error while delete', error);
              });
    }

    $scope.save = function () {
        if ($scope.contactModel.ContactID > 0) {
            contactService.put($scope.contactModel).then(function (d) {
                $scope.clear();
                bindGrid();
            },
              function (error) {
                  $log.error('error while getContacts', error);
              });
        }
        else {
            contactService.post($scope.contactModel).then(function (d) {
                $scope.clear();
                bindGrid();
            },
                function (error) {
                    $log.error('error while save', error);
                });
        }
    }

    $scope.clear = function () {
        $scope.contactModel = new 
            {
            ContactID: 0,
            FirstName: "",
            LastName: "",
            Email: "",
            Phone: "",
            CreatedBy: 0,
            CreatedOn: ""
        };
    }
});