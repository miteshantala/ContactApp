﻿/// <reference path="../AngularJS/angular.js" />
/// <reference path="AppModules.js" />


app.service('contactService', function ($http) {
    var contactApiUrl = "/api/Contact/";
    //Add
    this.post = function (contactModel) {
        var request = $http({
            method: "post",
            url: contactApiUrl,
            data: contactModel
        });
        return request;
    }
    //Get Single
    this.get = function (contactID) {
        return $http.get(contactApiUrl + contactID);
    }

    //Get List
    this.getContacts = function () {
        return $http.get(contactApiUrl);
    }
    //Update
    this.put = function (contactModel) {
        var request = $http({
            method: "put",
            url: contactApiUrl,
            data: contactModel
        });
        return request;
    }
    //Delete
    this.delete = function (contactID) {
        var request = $http({
            method: "delete",
            url: contactApiUrl + contactID
        });
        return request;
    }
});
